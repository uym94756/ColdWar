document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelectorAll(".slide");
    const totalSlides = slides.length;
    let index = 0;

    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    const imagenes = document.getElementById("imagenes");

    function mostrarImagen() {
        const desplazamiento = -index * 100; // Mueve el contenedor
        imagenes.style.transform = `translateX(${desplazamiento}%)`;
    }

    nextBtn.addEventListener("click", function () {
        index = (index + 1) % totalSlides;
        mostrarImagen();
    });

    prevBtn.addEventListener("click", function () {
        index = (index - 1 + totalSlides) % totalSlides;
        mostrarImagen();
    });

    
});
